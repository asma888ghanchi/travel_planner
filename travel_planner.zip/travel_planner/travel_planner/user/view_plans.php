<?php
include('../includes/config.php');
include('../includes/functions.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header('Location: login.php');
    exit();
}

$query = "SELECT * FROM plans";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>View Plans</title>
</head>
<body>
    <h1>Available Plans</h1>
    <?php while ($plan = mysqli_fetch_assoc($result)) { ?>
        <div>
            <h2><?php echo $plan['title']; ?></h2>
            <p><?php echo $plan['description']; ?></p>
            <p><?php echo $plan['price']; ?></p>
            <a href="buy_plan.php?plan_id=<?php echo $plan['id']; ?>">Buy</a>
        </div>
    <?php } ?>
</body>
</html>

<?php
include('../includes/config.php');
include('../includes/functions.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header('Location: login.php');
    exit();
}

// User-specific content
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
</head>
<body>
    <h1>Welcome, User</h1>
    <a href="add_plan.php">Add Plan</a>
    <a href="view_plans.php">View Plans</a>
</body>
</html>

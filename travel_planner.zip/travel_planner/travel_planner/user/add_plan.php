<?php
include('../includes/config.php');
include('../includes/functions.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $query = "INSERT INTO plans (user_id, title, description, price) VALUES ('$user_id', '$title', '$description', '$price')";
    if (mysqli_query($conn, $query)) {
        header('Location: dashboard.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Plan</title>
</head>
<body>
    <form method="POST" action="">
        <input type="text" name="title" required placeholder="Title">
        <textarea name="description" required placeholder="Description"></textarea>
        <input type="number" name="price" required placeholder="Price">
        <button type="submit">Add Plan</button>
    </form>
</body>
</html>

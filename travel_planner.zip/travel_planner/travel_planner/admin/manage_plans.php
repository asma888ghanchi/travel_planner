<?php
include('../includes/config.php');
include('../includes/functions.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

// Fetch and manage plans
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Plans</title>
</head>
<body>
    <h1>Manage Plans</h1>
    <!-- List plans and provide options to edit/delete -->
</body>
</html>

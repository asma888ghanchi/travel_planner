<!DOCTYPE html>
<html>
<head>
    <title>Travel Itinerary Planner</title>
</head>
<body>
    <h1>Welcome to the Travel Itinerary Planner</h1>
    <a href="admin/register.php">Admin Register</a>
    <a href="admin/login.php">Admin Login</a>
    <a href="user/register.php">User Register</a>
    <a href="user/login.php">User Login</a>
</body>
</html>
